import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App(){
  const [products,setProducts] = useState([]);

  useEffect(()=>{
    axios.get('https://your-backend-url/products')
    .then(res=>setProducts(res.data));
  },[]);

  return (
    <div style={{padding:20}}>
      <h2>My Shop</h2>
      {products.map(p=> (
        <div key={p._id}>
          <img src={p.img} width="120" />
          <p>{p.name}</p>
          <p>₹{p.price}</p>
        </div>
      ))}
    </div>
  );
}

export default App;
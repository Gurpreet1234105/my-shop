const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

mongoose.connect('mongodb://127.0.0.1:27017/shop');

const Product = mongoose.model('Product', {
  name:String,
  price:Number,
  img:String
});

app.get('/products', async (req,res)=>{
  res.send(await Product.find());
});

app.post('/products', async (req,res)=>{
  res.send(await Product.create(req.body));
});

app.listen(3000, ()=>console.log('Server running'));